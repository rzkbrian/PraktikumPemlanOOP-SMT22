

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UAP;


/**
 *
 * @author USER
 */
class FESTIVAL extends TiketKonser {
    //Do your magic here...
     public FESTIVAL() {
        super("FESTIVAL");
    }

    public double hitungHarga() {
        // Implementasikan perhitungan harga tiket FESTIVAL
        return 75.0;
    }
}