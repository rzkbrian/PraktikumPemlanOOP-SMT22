/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UAP;


/**
 *
 * @author USER
 */
class CAT1 extends TiketKonser {
    //Do your magic here...
    public CAT1() {
        super("CAT 1");
    }

    public double hitungHarga() {
        // Implementasikan perhitungan harga tiket CAT1
        return 50.0;
    }
}
