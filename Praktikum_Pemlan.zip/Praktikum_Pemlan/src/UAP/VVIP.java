/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UAP;


/**
 *
 * @author USER
 */
class VVIP extends TiketKonser {
    // Do your magic here...
    public VVIP() {
        super("VVIP");
    }

    public double hitungHarga() {
        // Implementasikan perhitungan harga tiket VVIP
        return 150.0;
    }
}
