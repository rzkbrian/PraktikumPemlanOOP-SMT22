/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bab8_Abstraksi;

/**
 *
 * @author USER
 */
public class Owner {
  private String name;

  // buat constructor
  public Owner(String name){
    this.name = name;
  } 

  // buat method getter untuk mendapatkan nilai name
  public String getName(){
    return name;
  }
}
